package ran.com.graphql.mutation;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;

import ran.com.graphql.entity.Vehicle;
import ran.com.graphql.service.VehicleService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class VehicleMutation implements GraphQLMutationResolver {

    @Autowired
    private VehicleService vehicleService;

    public Vehicle createVehicle(final String type, final String modelCode, final String brandName, final String launchDate) {
        return this.vehicleService.createVehicle(type, modelCode, brandName, launchDate);
    }
    
    public Vehicle updateVehicle(final int id,String type, final String modelCode, final String brandName, final String launchDate) {
        return this.vehicleService.updateVehicle(id,type, modelCode, brandName, launchDate);
    }
    
    public boolean deleteVehicle(final int id) {
        return  this.vehicleService.deleteVehicle(id);
    }
}
