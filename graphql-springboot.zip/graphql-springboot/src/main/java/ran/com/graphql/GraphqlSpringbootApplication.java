package ran.com.graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphqlSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphqlSpringbootApplication.class, args);
	}

}
